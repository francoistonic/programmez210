# Bdtheque
Cet ensemble de projet concerne l'article sur les API hypermedia avec threerest.

Le projet est appelé bdtheque et regroupe un ensemble de sous-projets.

  *bdtheque_simple* correspond à la partie **NodeJS chez les développeurs**
    bdtheque_simple est le projet pour la plus simple de création d'une API avec node.js
  
  *bdtheque_express* correspond à la partie **Express et compagnie**
    bdtheque_express est le projet où l'on inject 
  
  *bdtheque_routes* correspond à la partie **Tour de Gaule de notre API**
  
  *bdtheque_threerest* correspond à la partie **Le domaine d'HATEOAS**

  Cet article a été écrit par lynchmaniac et wmoulin
